import { ConfigModule } from '@nestjs/config';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ConnectorService } from './connector.service';
import { ConnectorCategoryService } from './connector-category.service';
import { ConnectorCredentialService } from './connector-credential.service';
import { ConnectorAuthServiceImpl } from './connector-auth.service';
import { ConnectorTransferService } from './connector-transfer.service';
import { M365TransferAdapter } from './adapters/m365-transfer.adapter';
import { Connector, ConnectorSchema } from './schemas/connector.schema';
import { ConnectorCategory, ConnectorCategorySchema } from './schemas/connector-category.schema';
import { ConnectorCredential, ConnectorCredentialSchema } from './schemas/connector-credential.schema';
import { AdminConnectorAuth, AdminConnectorAuthSchema } from './schemas/admin-connector-auth.schema';
import {
  AdminConnectorOAuthState,
  AdminConnectorOAuthStateSchema,
} from './schemas/admin-connector-oauth-state.schema';
import { AdminConnectorController } from './admin-connector.controller';
import { AdminConnectorCategoryController } from './admin-connector-category.controller';
import { AdminConnectorAuthCallbackController } from './admin-connector-auth-callback.controller';
import { UnifiedOAuthCallbackController } from './controllers/unified-oauth-callback.controller';
import { ConnectorController } from './connector.controller';
import { ConnectorUserService } from './connector-user.service';
import { AuthorizationModule } from '../authorization/authorization.module';
import { ConnectedAppModule } from '../connected-app/connected-app.module';
import {
  ConnectedAppOAuthState,
  ConnectedAppOAuthStateSchema,
} from '../connected-app/schemas/connected-app-oauth-state.schema';
import { WorkspaceModule } from '../workspace/workspace.module';
import { UserModule } from '../user/user.module';
import { LoggerModule } from '../logger';
import { CryptoService } from '@common/services/crypto.service';
import { ConnectorAdminAuthService } from './services/connector-admin-auth.service';

@Module({
  imports: [
    ConfigModule,
    MongooseModule.forFeature([
      { name: Connector.name, schema: ConnectorSchema },
      { name: ConnectorCategory.name, schema: ConnectorCategorySchema },
      { name: ConnectorCredential.name, schema: ConnectorCredentialSchema },
      { name: AdminConnectorAuth.name, schema: AdminConnectorAuthSchema },
      { name: AdminConnectorOAuthState.name, schema: AdminConnectorOAuthStateSchema },
      { name: ConnectedAppOAuthState.name, schema: ConnectedAppOAuthStateSchema },
    ]),
    AuthorizationModule,
    ConnectedAppModule,
    WorkspaceModule,
    UserModule,
    LoggerModule,
  ],
  controllers: [
    AdminConnectorController,
    AdminConnectorCategoryController,
    AdminConnectorAuthCallbackController,
    UnifiedOAuthCallbackController,
    ConnectorController,
  ],
  providers: [
    CryptoService,
    ConnectorService,
    ConnectorCategoryService,
    ConnectorAdminAuthService,
    ConnectorCredentialService,
    ConnectorAuthServiceImpl,
    ConnectorTransferService,
    M365TransferAdapter,
    ConnectorUserService,
    {
      provide: 'ConnectorAuthService',
      useExisting: ConnectorAuthServiceImpl,
    },
  ],
  exports: [ConnectorService, ConnectorCredentialService, 'ConnectorAuthService', ConnectorTransferService],
})
export class ConnectorModule {}
